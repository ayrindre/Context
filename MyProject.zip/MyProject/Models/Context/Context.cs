using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace MyProject
{
    public class Context : DbContext
    {
        public Context(DbContextOptions<Context> options) : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
         {
         base.OnConfiguring(optionsBuilder);
         }
        
        // public DbSet<Tbl_User> Tbl_Users { get; set; }
    }
    
}